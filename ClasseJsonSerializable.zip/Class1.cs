﻿using System.Text.Json.Serialization;

namespace $rootnamespace$;

public sealed class $safeitemname$
{
    
}

[JsonSerializable(typeof($safeitemname$))]
public partial class $safeitemname$Context: JsonSerializerContext
{
    // ne rien mettre
}
