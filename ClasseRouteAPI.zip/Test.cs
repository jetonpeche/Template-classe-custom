﻿using Microsoft.AspNetCore.Mvc;
using System.Net;
using System.Net.Http;

namespace $safeitemname$;

public static class $safeitemname$
{
    public static RouteGroupBuilder AjouterRoute(this RouteGroupBuilder builder)
    {
        // builder.WithOpenApi();

        builder.MapGet("lister", ListerAsync)
            .ProducesProblem(StatusCodes.Status503ServiceUnavailable);

        builder.MapGet("info/{id}", InfosAsync)
            .ProducesValidationProblem()
            .ProducesProblem(StatusCodes.Status404NotFound)
            .ProducesProblem(StatusCodes.Status503ServiceUnavailable)
            .WithName("");

        builder.MapPost("ajouter", AjouterAsync)
            .Produces(StatusCodes.Status201Created)
            .ProducesValidationProblem()
            .ProducesProblem(StatusCodes.Status503ServiceUnavailable);

        builder.MapPut("modifier", ModifierAsync)
            .Produces(StatusCodes.Status204NoContent)
            .ProducesValidationProblem()
            .ProducesProblem(StatusCodes.Status404NotFound)
            .ProducesProblem(StatusCodes.Status503ServiceUnavailable);

        builder.MapDelete("supprimer/{id}", SupprimerAsync)
            .Produces(StatusCodes.Status204NoContent)
            .ProducesProblem(StatusCodes.Status404NotFound)
            .ProducesProblem(StatusCodes.Status503ServiceUnavailable);

        return builder;
    }

    static async Task<IResult> ListerAsync()
    {
        try
        {
            return Results.OK();
        }
        catch
        {
            return Results.Extensions.ErreurConnexionBdd();
        }
    }

    static async Task<IResult> InfosAsync([FromRoute(Name = "id")] int _id)
    {
        try
        {
            return Results.OK();
        }
        catch
        {
            return Results.Extensions.ErreurConnexionBdd();
        }
    }

    static async Task<IResult> AjouterAsync(HttpContext _httpContext,
                                            [FromServices] LinkGenerator _linkGenerator,
                                            [FromBody] object _)
    {
        try
        {
            string url = _linkGenerator.GetUriByName(_httpContext, "")!;

            return Results.Created(url, new { });
        }
        catch
        {
            return Results.Extensions.ErreurConnexionBdd();
        }
    }

    static async Task<IResult> ModifierAsync()
    {
        try
        {
            return Results.NoContent();
        }
        catch
        {
            return Results.Extensions.ErreurConnexionBdd();
        }
    }

    static async Task<IResult> SupprimerAsync([FromRoute(Name = "id")] int _id)
    {
        try
        {
            return Results.NoContent();
        }
        catch
        {
            return Results.Extensions.ErreurConnexionBdd();
        }
    }
}

